package edu.miami.c10656908.TalkingPicture;

import android.content.ContentValues;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Path;
import android.graphics.drawable.Drawable;
import android.media.Image;
import android.media.MediaPlayer;
import android.provider.MediaStore;
import android.speech.tts.TextToSpeech;
import android.support.v4.widget.SimpleCursorAdapter;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.util.Random;

public class MainActivity extends AppCompatActivity implements SimpleCursorAdapter.ViewBinder, TextToSpeech.OnInitListener {


    private Cursor audioCursor;
    private MediaPlayer myPlayer;
    private imageNoteDB notesDB;
    private Cursor noteCursor;
    private Cursor imageMediaCursor;
    private TextToSpeech mySpeaker;
    private SimpleCursorAdapter cursorAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        int idIndex;
        int dataIndex;
        int audioDataIndex;
        String audioFilename;
        int audioposition;
        int min = 0;
        int audiomax;

        ListView theList;

        theList = (ListView)findViewById(R.id.the_list);

        String[] displayFields = {
                "image_id",
                "note",
                "recording"
        };
        int[] displayViews = {
                R.id.image,
                R.id.note,
                R.id.checkbox
        };
        String[] queryFields = {
                MediaStore.Images.Media._ID,
                MediaStore.Images.Media.TITLE,
                MediaStore.Images.Media.DATA
        };

        myPlayer = new MediaPlayer();

        String[] audioqueryFields = {
                MediaStore.Audio.Media._ID,
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.DATA     //----Path to file on disk
        };

        audioCursor = getContentResolver().query(
                MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,audioqueryFields,null,null,
                MediaStore.Audio.Media.TITLE + " ASC");

        try {
            audioCursor.moveToFirst();
        }
        catch (Exception e) {
            Log.i("error","null cursor");
        };
        Random random = new Random();
        audioDataIndex = audioCursor.getColumnIndex(
                MediaStore.Audio.Media.DATA);
        audiomax = audioCursor.getCount() - 1;
        audioposition = random.nextInt((audiomax - min) + 1) + min;
        audioCursor.moveToPosition(audioposition);
        audioFilename = audioCursor.getString(audioDataIndex);

        try {
            myPlayer.setDataSource(audioFilename);
            myPlayer.prepare();
            myPlayer.start();
        } catch (IOException e) {
            //----Should do something here
        }

        notesDB = new imageNoteDB(this);

       imageMediaCursor = getContentResolver().query(
                MediaStore.Images.Media.EXTERNAL_CONTENT_URI,queryFields,null,null,
                MediaStore.Images.Media.DEFAULT_SORT_ORDER);
        if (imageMediaCursor.moveToFirst()) {
            updateImageDBFromContent();

            noteCursor = notesDB.fetchAllNotes();

            cursorAdapter = new SimpleCursorAdapter(this, R.layout.list_item_layout, noteCursor, displayFields, displayViews, 0);
            cursorAdapter.setViewBinder(this);
            theList.setAdapter(cursorAdapter);
        }
        mySpeaker = new TextToSpeech(this,this);
    }

    private void updateImageDBFromContent() {

        ContentValues imageData;
        int imageMediaId;

        do {
            imageMediaId = imageMediaCursor.getInt(
                    imageMediaCursor.getColumnIndex(MediaStore.Images.Media._ID));
            if (notesDB.getNoteByImageMediaId(imageMediaId) == null) {
                imageData = new ContentValues();

               //imageData.put("note", "default");
                imageData.put("image_id",imageMediaId);

                notesDB.addNote(imageData);
            }
        } while (imageMediaCursor.moveToNext());
    }



    @Override
    public boolean setViewValue(View view, Cursor cursor, int columnIndex) {
        Log.i("setViewValue", "entered setViewValue at all");

        switch (view.getId()) {
            case R.id.image:
                Log.i("test", view.getTag().toString());
                Log.i("setViewValue", "entered imagecase at all");
                ImageView image = (ImageView)view;

                int idIndex = 0;
                int imageId = cursor.getInt(columnIndex);
                boolean imageFound = false;
                String imageFilename;
                Bitmap thumbnailBitmap;
                if(imageMediaCursor.moveToFirst()) {
                    idIndex = imageMediaCursor.getColumnIndex(MediaStore.Audio.Media._ID);
                    do {
                        imageFound = imageId == imageMediaCursor.getInt(idIndex);
                    } while(!imageFound && imageMediaCursor.moveToNext());
                }
                if(imageFound) {
                    imageFilename = imageMediaCursor.getString(imageMediaCursor.getColumnIndex(MediaStore.Images.Media.DATA));
                    Log.i("test", "test: " + imageFilename);

                   /* thumbnailBitmap =  MediaStore.Images.Thumbnails.getThumbnail(
                            getContentResolver(),imageMediaCursor.getInt(idIndex),
                            MediaStore.Images.Thumbnails.MICRO_KIND,null);*/

                    //Log.i("test", "test: " + thumbnailBitmap);

                    //if (thumbnailBitmap != null) {
                    File imageFile = new File(imageFilename);
                    Bitmap myBitmap = BitmapFactory.decodeFile(imageFile.getAbsolutePath());
                    image.setImageBitmap(myBitmap);
                    //image.setImageResource(R.mipmap.ic_launcher);
                    //image.setImageDrawable(myimage);
                      //  image.setImageBitmap(thumbnailBitmap);
                   // } else {
                    //    Toast.makeText(this,"Can't get thumbnail",Toast.LENGTH_SHORT).
                    //            show();
                   // }
                }
                else {
                    Toast.makeText(this, "Can't find image", Toast.LENGTH_SHORT).show();
                }
                break;

            case R.id.note:
                return false;
            case R.id.checkbox:
                CheckBox checkBox = (CheckBox)view;

                if(cursor.getBlob(columnIndex) != null) {
                    checkBox.setChecked(true);
                }
                else {
                    checkBox.setChecked(false);
                }
                break;
            default:
                Toast.makeText(this, "Can't find anything", Toast.LENGTH_SHORT).show();
                break;
        }
        return false;
    }



    @Override
    protected void onDestroy() {
        super.onDestroy();
        myPlayer.release();
        audioCursor.close();
        imageMediaCursor.close();

        noteCursor.close();;
        notesDB.close();

        //myHandler.removeCallbacks(myUtteranceCompleted);
        mySpeaker.shutdown();
    }
    @Override
    public void onInit(int status) {
        if (status == TextToSpeech.SUCCESS) {
            Log.i("I", "Text to speech success");
        } else {
            Toast.makeText(this,"You need to install TextToSpeech",
                    Toast.LENGTH_LONG).show();
            Log.i("I", "Text to speech failure");
            finish();
        }
    }
}
